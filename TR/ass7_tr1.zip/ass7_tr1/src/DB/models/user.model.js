import mongoose from "mongoose";

const userSchema = new mongoose.Schema({
    name: String,
    email: String,
    password: String,
    age: Number,
    confirmed: Boolean
})

const userModel = mongoose.model('user', userSchema)

export default userModel
import userModel from "../../DB/models/user.model.js"

export const createUser = (req, res, next) =>{
    const user = new userModel(req.body);
    res.status(201).json({meassage: 'user added', user})
}